/*
    (c) 2016 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

#include <stdint.h>
#include "RFID_driver.h"
#include "pin_manager.h"
#include "drivers/spi_master.h"
#include "delay.h"

//*********************************************************
//          CR95HF Driver Functions
//*********************************************************
void RFID_SpiStartUpSequence (void)
{
    DELAY_microseconds(15);
    LATEbits.LATE1 = 1; /* set RFid_SSI_0 output high */
    LATAbits.LATA2 = 0; /* set RFid_SSI_1 output low */
    LATCbits.LATC0 = 0; /* set RFid_INT_I output low */
    DELAY_microseconds(15);
    LATCbits.LATC0 = 1; /* set RFid_INT_I output high */
    DELAY_microseconds(15);
}

void RFID_ToggleIntI(void)
{
    LATCbits.LATC0 = 0; /* set RFid_INT_I output low */   
    DELAY_milliseconds(10);
    LATCbits.LATC0 = 1; /* set RFid_INT_I output high */
    DELAY_milliseconds(10);
}

bool RFID_GetIntO(void)
{
    return PORTBbits.RB0 /* get RFid_INT_O value */;
}

void RFID_SendCommand(uint8_t command, uint8_t dataLength, uint8_t* data)
{   
    // Send Command:    0x00
    uint8_t dataIndex = 0;
    while(!spiMaster[rfID].spiOpen())
    {
    } 
    LATEbits.LATE0 = 0; /* set RFid_nCS output low */
    DELAY_microseconds(50);
    spiMaster[rfID].exchangeByte(0x00);          // Control Byte 
    spiMaster[rfID].exchangeByte(command);
    if (dataLength)
    {
        spiMaster[rfID].exchangeByte(dataLength);
        for (dataIndex = 0; dataIndex < dataLength; dataIndex++)
        {
            spiMaster[rfID].exchangeByte(*data++);
        }
    }
    LATEbits.LATE0 = 1; /* set RFid_nCS output high */ 
    DELAY_microseconds(50);
    spiMaster[rfID].spiClose();
}

void RFID_SoftwareReset(void)
{   
    // Reset:   0x01
    while(!spiMaster[rfID].spiOpen())
    {
    }
    LATEbits.LATE0 = 0; /* set RFid_nCS output low */
    DELAY_microseconds(50);
    spiMaster[rfID].exchangeByte(0x01);          // Control Byte    
    LATEbits.LATE0 = 1; /* set RFid_nCS output high */ 
    DELAY_microseconds(50);
    spiMaster[rfID].spiClose();   
}

uint8_t RFID_ReadCommand(uint8_t* response)
{   
    // Read:    0x02
    uint8_t dataIndex = 0;
    uint8_t responseLength = 0x00;
    uint8_t responseByte = 0x00;
    CR95HF_Flagbits_t responseCode;
    responseCode.flagsBitMap = 0x00;
    
    while(!spiMaster[rfID].spiOpen())
    {
    }
    LATEbits.LATE0 = 0; /* set RFid_nCS output low */
    DELAY_microseconds(50);
    spiMaster[rfID].exchangeByte(0x02);          // Control Byte  
    responseCode.flagsBitMap = spiMaster[rfID].exchangeByte(RFID_DUMMY_EXCHANGE);
    if ( (responseCode.flagsBitMap == RFID_ECHO) || (responseCode.flagsBitMap == 0x80) )     // Copy Response Codes that useful
    {
        *response++ = responseCode.flagsBitMap;
    }
    if ( (responseCode.flagReadDataReady) || (responseCode.flagsBitMap == 0x80) && (responseCode.flagsBitMap != RFID_ECHO))
    {
        responseLength = spiMaster[rfID].exchangeByte(RFID_DUMMY_EXCHANGE);
        for (dataIndex = 0; dataIndex < responseLength; dataIndex++)
        {
            responseByte = spiMaster[rfID].exchangeByte(RFID_DUMMY_EXCHANGE);
            *response++ = responseByte;
        }
    }
    LATEbits.LATE0 = 1; /* set RFid_nCS output high */
    DELAY_microseconds(50);
    spiMaster[rfID].spiClose();
    return responseLength;
}

CR95HF_Flagbits_t RFID_PollCR95HF(void)
{   
    // Poll:    0x03
    CR95HF_Flagbits_t flagResult;
    while(!spiMaster[rfID].spiOpen())
    {
    }
    LATEbits.LATE0 = 0; /* set RFid_nCS output low */
    DELAY_microseconds(50);
    spiMaster[rfID].exchangeByte(0x03);          // Control Byte  
    flagResult.flagsBitMap = spiMaster[rfID].exchangeByte(RFID_DUMMY_EXCHANGE);
    LATEbits.LATE0 = 1; /* set RFid_nCS output high */ 
    DELAY_microseconds(50);
    spiMaster[rfID].spiClose();
    return flagResult;
}

void RFID_BlockingReadReadyPollingSoftware(void)
{
    CR95HF_Flagbits_t cr95HF_FlagResponse;
    cr95HF_FlagResponse.flagsBitMap = 0x00;

    while(!cr95HF_FlagResponse.flagReadDataReady)
    {
        cr95HF_FlagResponse = RFID_PollCR95HF();
    }
}

void RFID_BlockingReadReadyPollingHardware(void)
{
    while (PORTBbits.RB0 /* get RFid_INT_O value */)
    {
    }
}

bool RFID_IsReadReadyHardwarePollingNonBlocking(void)
{
    if (!PORTBbits.RB0 /* get RFid_INT_O value */)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool RFID_IsReadReadySoftwarePollingNonBlocking(void)
{
    CR95HF_Flagbits_t cr95HF_FlagResponse;
    cr95HF_FlagResponse.flagsBitMap = 0x00;

    cr95HF_FlagResponse = RFID_PollCR95HF();
    
    if (cr95HF_FlagResponse.flagReadDataReady)
    {
        return true;
    }
    else
    {
        return false;
    }
}
/**
 End of File
 */