/*
    (c) 2016 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

#ifndef RFID_DRIVER_H
#define	RFID_DRIVER_H

#include <stdint.h>
#include <stdbool.h>

// Response Code Flag Interpretation
typedef union
{
    uint8_t flagsBitMap;
    struct {
        unsigned int flagsNotUsedLowBits     :2;
        unsigned int flagReadDataReady       :1;
        unsigned int flagSendDataReady       :1;
        unsigned int flagsNotUsedHighBits    :4;
    };  
}CR95HF_Flagbits_t;

// CR95HF Commands Definition
#define    RFID_DUMMY_EXCHANGE         0x00
#define    RFID_IDN                    0x01
#define    RFID_PROTOCOL_SELECT        0x02
#define    RFID_SEND_RECV              0x04
#define    RFID_IDLE                   0x07
#define    RFID_RDREG                  0x08
#define    RFID_WRREG                  0x09
#define    RFID_BAUDRATE               0x0A
#define    RFID_ECHO                   0x55

void RFID_SpiStartUpSequence (void);
void RFID_ToggleIntI(void);
bool RFID_GetIntO(void);
void RFID_SendCommand(uint8_t, uint8_t, uint8_t*);
void RFID_SoftwareReset(void);
uint8_t RFID_ReadCommand(uint8_t*);
CR95HF_Flagbits_t RFID_PollCR95HF(void);
void RFID_BlockingReadReadyPollingSoftware(void);
void RFID_BlockingReadReadyPollingHardware(void);
bool RFID_IsReadReadyHardwarePollingNonBlocking(void);
bool RFID_IsReadReadySoftwarePollingNonBlocking(void);

#endif	/* RFID_DRIVER_H */